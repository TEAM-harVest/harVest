package com.itwillbs.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.itwillbs.dao.ProjectDAO;

@Service
public class ProjectServiceImpl implements ProjectService {
 
	@Inject
	private ProjectDAO projectDAO;
}
