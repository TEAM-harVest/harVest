package com.itwillbs.dao;

public interface ProjectDAO {
 
}
