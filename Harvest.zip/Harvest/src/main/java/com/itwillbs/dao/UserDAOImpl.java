package com.itwillbs.dao;

import java.sql.Timestamp;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
//import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.itwillbs.domain.UserDTO;

@Repository
public class UserDAOImpl implements UserDAO {

	// 마이바티스 객체생성 => 멤버변수 자동 주입
	@Inject
	private SqlSession sqlSession;
	private static final String namespace = "com.itwillbs.mappers.sampleMapper";

	@Override
	public UserDTO getMember(String id) {
		return sqlSession.selectOne(namespace+".getMember", id);
	}
	
	

	
	
}
