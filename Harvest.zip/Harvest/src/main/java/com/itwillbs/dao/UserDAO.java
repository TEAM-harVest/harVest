package com.itwillbs.dao;

import java.util.List;

import com.itwillbs.domain.UserDTO;

public interface UserDAO {
	
	public UserDTO getMember(String id);
}
